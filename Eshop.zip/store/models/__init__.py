from .product import Product  # From current directory we imported Product class
from .category import Category
from .customer import Customer
from .orders import Order
